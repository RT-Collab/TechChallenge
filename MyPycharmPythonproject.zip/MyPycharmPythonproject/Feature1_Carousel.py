from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import unittest
import HtmlTestRunner


#   Initiate Chrome Browser
browser = webdriver.Chrome(executable_path=r'C:\\Users\RT\Downloads\chromedriver_win32/chromedriver.exe')
#   Navigate to the specified URL/Website
browser.get('https://www.digitalpulse.pwc.com.au')
browser.maximize_window()
browser.implicitly_wait(30)  # 30 is in seconds
#   Find the Next button for the Carousel and click to see the next 3 ads
NavNext = browser.find_element_by_xpath("/html/body/div[1]/section[2]/div/div/ul/li[2]/a")

print(NavNext)
NavNext.click()

#  Simple conditional check
# The below conditional check is currently returning a false positive as the application is unable to click on the navigation arrows
# [  element is not interactable error]. the approach is simple but in this instance a false positive is thrown. This can be fixed.
if browser.page_source.__contains__("You say you want a revolution? Then partner 4IR with cybersecurity"):
    print("Next button NOT Clicked")
else:
    print("Next 3 featured articles have been loaded!!!")

#   Find the Previous button for the Carousel and click to see the prev 3 ads
NavPrev = browser.find_element_by_xpath("/html/body/div[1]/section[2]/div/div/ul/li[1]/a")
print(NavPrev)
NavPrev.click()

if browser.page_source.__contains__("You say you want a revolution? Then partner 4IR with cybersecurity"):
    print("Previous button  Clicked")
else:
    print("Previous 3 featured articles have NOT been loaded!!!")

#   EOF Flag
print("All Specified Actions have been COMPLETED")

if __name__ == '__main__':
  unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='C:\Development\Python\MyFirstPycharmPythonproject'))