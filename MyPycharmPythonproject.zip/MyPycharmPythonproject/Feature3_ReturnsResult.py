from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import unittest
import HtmlTestRunner


#   Initiate Chrome Browser
browser = webdriver.Chrome(executable_path=r'C:\\Users\RT\Downloads\chromedriver_win32/chromedriver.exe')
#   Navigate to the specified URL/Website
browser.get('https://www.digitalpulse.pwc.com.au')

#   Find the Magnifying Glass Icon and click to Trigger the Serach field
SearchIcon = browser.find_element_by_xpath("/html/body/div[1]/header/div[1]/div/i[2]")
SearchIcon.click()

#   Find Search field
SearchField = browser.find_element_by_name("s")

#   Enter search string into the search field
SearchField.send_keys("Single page application")
SearchField.send_keys(Keys.RETURN)
#   Conditional loop to evaluate if results  returned and output if true or False

if browser.page_source.__contains__("Please try another search"):
    print("no results found")
else:
    print("Results Returned!!!")

#   EOF Flag
print("All Specified Actions have been COMPLETED")


if __name__ == '__main__':
  unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='C:\Development\Python\MyFirstPycharmPythonproject'))