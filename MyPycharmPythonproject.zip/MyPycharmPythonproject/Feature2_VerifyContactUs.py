from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import unittest
import HtmlTestRunner


#   Initiate Chrome Browser
browser = webdriver.Chrome(executable_path=r'C:\\Users\RT\Downloads\chromedriver_win32/chromedriver.exe')
#   Navigate to the specified URL/Website
browser.get('https://www.digitalpulse.pwc.com.au')

#   Find the Magnifying Glass Icon and click to Trigger the Serach field
HamburgerIcon = browser.find_element_by_xpath("/html/body/div[1]/header/div[1]/div/i[1]")
HamburgerIcon.click()

#   Find Search field
try:
    element = WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.ID, "menu-item-65" )))
finally:

    ContactUs = browser.find_element_by_id("menu-item-65")
    ContactUs.click()

# verify PwC Digital Services exists
if browser.page_source.__contains__("PwC Digital Services"):
    print("PwC Digital Services details are displayed")
elif  browser.page_source.__contains__("https://digital.pwc.com/en/contact-us.html"):
    print("PwC Digital Services Link is displayed")
else:
    print("PwC Digital Services details are NOT displayed")


# verify Digital Pulse editorial team exists
if browser.page_source.__contains__("editorial team"):
    print("Digital Pulse editorial team details are displayed")
else:
    print("Digital Pulse editorial team details are NOT displayed")

# verify Careers at PwC exists
if browser.page_source.__contains__("Careers at"):
    print("Careers at PwC details are displayed")
elif  browser.page_source.__contains__("https://www.pwc.com/gx/en/careers.html"):
    print("Careers at PwC Link is displayed")
else:
    print("Careers at PwC details are NOT displayed")

# verify General enquiries exists
if browser.page_source.__contains__("enquiries"):
    print("General Enquiries details are displayed")
elif  browser.page_source.__contains__("https://www.pwc.com/gx/en/careers.html"):
    print("General EnquiriesLink is displayed")
else:
    print("Careers at PwC details are NOT displayed")

#   EOF Flag
print("All Specified Actions have been COMPLETED")

if __name__ == '__main__':
  unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='C:\Development\Python\MyFirstPycharmPythonproject'))